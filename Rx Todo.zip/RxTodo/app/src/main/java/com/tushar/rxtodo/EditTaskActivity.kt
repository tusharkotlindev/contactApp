package com.tushar.rxtodo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.room.Room
import com.tushar.rxtodo.db.Contact
import com.tushar.rxtodo.db.ContactDatabase
import kotlinx.android.synthetic.main.activity_edit_task.*

class EditTaskActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_task)
        val contact = intent.getParcelableExtra<Contact>("contact_data")
        edit_text_email.setText(contact?.email)
        edit_text_name.setText(contact?.contactName)
        update_btn.setOnClickListener {
            val contactDao = Room.databaseBuilder(this,ContactDatabase::class.java,"contact").allowMainThreadQueries().build().getContactDao()
            val name = edit_text_name.text.toString()
            val email = edit_text_email.text.toString()
            val updatedContact = Contact(email,name)
            contactDao.updateContact(updatedContact)
        }
    }
}