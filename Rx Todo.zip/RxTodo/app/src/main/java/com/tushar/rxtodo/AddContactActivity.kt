package com.tushar.rxtodo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.room.Room
import com.tushar.rxtodo.db.Contact
import com.tushar.rxtodo.db.ContactDatabase
import kotlinx.android.synthetic.main.activity_add_contact.*

// delhi crime
class AddContactActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_contact)
        val db = Room.databaseBuilder(applicationContext,ContactDatabase::class.java,"contact").allowMainThreadQueries().build()
        save_contact.setOnClickListener {
            db.getContactDao().insertContact(Contact(email_contact_edit_text.text.toString(),contact_name_edit_text.text.toString()))
            finish()
        }
    }
}