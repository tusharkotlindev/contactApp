package com.tushar.rxtodo.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.tushar.rxtodo.EditTaskActivity
import com.tushar.rxtodo.R
import com.tushar.rxtodo.db.Contact
import com.tushar.rxtodo.db.ContactDatabase
import kotlinx.android.synthetic.main.contact_holder_view.view.*

private const val TAG = "ContactAdapter"
class ContactAdapter(private val contactList:ArrayList<Contact>,
                     private val layoutInflater: LayoutInflater, private val mContext: Context) : RecyclerView.Adapter<ContactAdapter.ContactHolder>() {
    inner class ContactHolder(contactView: View):RecyclerView.ViewHolder(contactView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactHolder {
        val contactView = LayoutInflater.from(parent.context).inflate(R.layout.contact_holder_view,parent,false)
        return ContactHolder(contactView)
    }

    override fun onBindViewHolder(holder: ContactHolder, position: Int) {
        val contactDao = Room.databaseBuilder(mContext,ContactDatabase::class.java,"contact").allowMainThreadQueries().build().getContactDao()

        holder.itemView.apply {
            user_email_tv.text = contactList[position].email
            user_name_tv.text = contactList[position].contactName
            btn_delete.setOnClickListener {
                val contact = contactList[position]
                contactDao.deleteContact(contact)
                contactList.removeAt(position)
                notifyDataSetChanged()
            }
            setOnClickListener {
                val intent = Intent(mContext,EditTaskActivity::class.java)
                intent.putExtra("contact_data",contactList[position])
                mContext.startActivity(intent)
            }
        }
    }

    override fun getItemCount(): Int {
        return contactList.size
    }

}