package com.tushar.rxtodo.db

import androidx.room.*

@Dao
interface ContactDao {
    @Insert
    fun insertContact(contact: Contact):Long

    @Query("select * from contacts")
    fun getAllContacts():List<Contact>

    @Update
    fun updateContact(contact: Contact)

    @Delete
    fun deleteContact(contact: Contact)
}